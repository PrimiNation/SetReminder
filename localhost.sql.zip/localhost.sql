-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 15, 2019 at 02:33 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `user`
--
CREATE DATABASE `user` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `user`;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) NOT NULL,
  `Email` varchar(25) NOT NULL,
  `Password` varchar(25) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`ID`, `username`, `Email`, `Password`) VALUES
(1, 'Priyam Jaiswal', 'priyam@gmail.com', '123456'),
(2, 'Anonymous', 'anons@gmail.com', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `setreminder`
--

CREATE TABLE IF NOT EXISTS `setreminder` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `daterem` varchar(20) DEFAULT NULL,
  `subject` varchar(25) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `email` varchar(25) DEFAULT NULL,
  `contact` int(12) DEFAULT NULL,
  `sms` int(12) DEFAULT NULL,
  `days` varchar(20) DEFAULT NULL,
  `enb/dsb` tinyint(1) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `setreminder`
--

INSERT INTO `setreminder` (`ID`, `daterem`, `subject`, `description`, `email`, `contact`, `sms`, `days`, `enb/dsb`) VALUES
(3, '2019-10-09', 'Jogging', 'Morning walk', 'priyam@gmail.com', 1234567890, 987654321, '7 days', 0),
(5, '2019-10-01', 'jogging', 'qwerty', 'priyam@gmail.com', 987654321, 1234567890, '7 days', 0);
